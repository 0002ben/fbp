from __future__ import unicode_literals

from django.apps import AppConfig


class FairbusinesspracticesConfig(AppConfig):
    name = 'FairBusinessPractices'
    verbose_name = 'Fair Business Practices'